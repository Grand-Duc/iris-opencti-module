from app.models.models import Ioc
from app.models.models import CeleryTaskMeta
from app.schema.marshables import CaseDetailsSchema
from app.models.cases import Cases
from app.models import *
from app.datamgmt.case.case_iocs_db import get_detailed_iocs
from sqlalchemy import and_

from sqlalchemy import desc
import json

class IrisHandler:
    def __init__(self, logger):
        self.log = logger

    def retrieve_ioc(self, ioc_id: int) -> Ioc:
        ioc = Ioc.query.filter(Ioc.ioc_id == ioc_id).first()
        if not ioc:
            self.log.error(f"IOC with ID {ioc_id} not found.")
            return None
        else:
            self.log.info(f"Retrieved IOC with ID {ioc.ioc_value}.")
        return ioc

    # def list_dim_tasks(self, count):
    #     tasks = CeleryTaskMeta.query.filter(
    #         ~ CeleryTaskMeta.name.like('app.iris_engine.updater.updater.%')
    #     ).order_by(desc(CeleryTaskMeta.date_done)).limit(count).all()

    #     APP_NAME = "iris_opencti_module" #TODO : get from config

    #     case_id = None

    #     for row in tasks:

    #         try:
    #             _ = row.result
    #         except AttributeError as e:
    #             self.log.error(f"Legacy task encountered: {e}")
    #             continue

    #         if row.kwargs and row.kwargs != b'{}':
    #             kwargs = json.loads(row.kwargs.decode('utf-8'))
    #             if kwargs:
    #                 module_name = kwargs.get('module_name', 'Unknown')
    #                 case_id = kwargs.get('caseid', 'Unknown')
    #                 if module_name == APP_NAME:
    #                     return case_id

    # def retrieve_case_id(self): #TODO !! Cannot work sinc task is updated AFTER the full handle is processed
    #     case_id = self.list_dim_tasks(5)
    #     if case_id is None:
    #         self.log.error("No case ID found in the last 5 tasks.")
    #     else:
    #         self.log.info(f"Retrieved case ID: {case_id}")
    #     return case_id
    
    # def retrieve_case_id_v2(self, ioc_value):
    #     result = Ioc.query.filter(Ioc.ioc_value == ioc_value).first()
    #     self.log.info(f"Search result: {result}")
    #     test_ioc = Ioc.query.first()
    #     test_case = Cases.query.first()
    #     self.log.info(f"Test IOC: {test_ioc if test_ioc else 'None'}, Test Case: {test_case if test_case else 'None'}")


    #     for attribute_name in dir(test_ioc):
    #         if not attribute_name.startswith('__'):
    #             try:
    #                 attribute_value = getattr(test_ioc, attribute_name)
    #                 self.log.info(f"{attribute_name}: {attribute_value}")
    #             except AttributeError:
    #                 self.log.info(f"{attribute_name}: <unreadable>")
    #     for attribute_name in dir(test_case):
    #         if not attribute_name.startswith('__'):
    #             try:
    #                 attribute_value = getattr(test_case, attribute_name)
    #                 self.log.info(f"{attribute_name}: {attribute_value}")
    #             except AttributeError:
    #                 self.log.info(f"{attribute_name}: <unreadable>")


    # def get_case(self): 
    #     case_id = self.retrieve_case_id()
    #     if case_id is None:
    #         self.log.error("No case ID provided.")
    #         return "Unknown Case"
    #     case = Cases.query.filter(Cases.case_id == case_id).first()
    #     if not case:
    #         self.log.error(f"Case with ID {case_id} not found.")
    #         return None
    #     else:
    #         self.log.info(f"Retrieved case {case.name}")
    #         return case

    def get_case_iocs(self, case_id):
        if not case_id:
            self.log.error("No case ID provided.")
            return []

        iocs = get_detailed_iocs(case_id)
        if not iocs:
            self.log.error(f"No IOCs found for case ID {case_id}.")
            return []

        self.log.info(f"Retrieved {len(iocs)} IOCs for case ID {case_id}.")
        return iocs