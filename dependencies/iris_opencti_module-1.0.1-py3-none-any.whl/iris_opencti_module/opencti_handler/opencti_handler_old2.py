import requests

class OpenCTIHandler:

    ATTRIBUTE_CONFIG = {
        'md5': {
            'key_conversion': 'hashes.MD5',
            'type_conversion': 'File',
            'create_type_conversion': 'StixFile',
            'other_type_conversion': 'StixFile',
            'upload_type': 'MD5',
            'is_hash': True,
        },
        'sha1': {
            'key_conversion': 'hashes.SHA-1',
            'type_conversion': 'File',
            'create_type_conversion': 'StixFile',
            'other_type_conversion': 'StixFile',
            'upload_type': 'SHA-1',
            'is_hash': True,
        },
        'sha256': {
            'key_conversion': 'hashes.SHA-256',
            'type_conversion': 'File',
            'create_type_conversion': 'StixFile',
            'other_type_conversion': 'StixFile',
            'upload_type': 'SHA-256',
            'is_hash': True,
        },
        'sha512': {
            'key_conversion': 'hashes.SHA-512',
            'type_conversion': 'File',
            'create_type_conversion': 'StixFile',
            'other_type_conversion': 'StixFile',
            'upload_type': 'SHA-512',
            'is_hash': True,
        },
        'ip-any': {
            'key_conversion': 'value',
            'type_conversion': 'IPv4-Addr',
            'create_type_conversion': 'IPv4-Addr',
            'other_type_conversion': 'IPv4Addr',
            'is_hash': False,
        },
        'url': {
            'key_conversion': 'value',
            'type_conversion': 'Url',
            'create_type_conversion': 'Url',
            'other_type_conversion': 'Url',
            'is_hash': False,
        },
        'domain': {
            'key_conversion': 'value',
            'type_conversion': 'Domain-Name',
            'create_type_conversion': 'DomainName',
            'other_type_conversion': 'DomainName',
            'is_hash': False,
        }
    }

    def __init__(self, mod_config, logger):
        self.mod_config = mod_config
        self.log = logger
        self.opencti_api_url = mod_config.get('opencti_url', None)
        self.opencti_api_key = mod_config.get('opencti_api_key', None)
        self.opencti_client = None


    def send_query(self, QUERY, variables=None):
        HEADERS = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.opencti_api_key}",
        }
        try:
            result = requests.post(self.opencti_api_url, headers=HEADERS, json={
                                   "query": QUERY, "variables": variables}, verify=False)
            result.raise_for_status()
            return result
        except requests.exceptions.RequestException as e:
            self.log.error(f"Error sending query to OpenCTI: {e}")
            return None

    def list_IR_case(self):
        QUERY = """
            query filteredIntrusionSets($filters: FilterGroup) {
                caseIncidents(filters: $filters, orderBy: name) {
                    edges {
                        node {
                            id
                            name
                            standard_id
                            created_at
                            updated_at
                            createdBy {
                                id
                                name
                            }
                            objectParticipant {
                                name
                            }
                            objectAssignee {
                                name
                            }
                            entity_type
                            is_inferred
                            status {
                                type
                            }
                            description
                            content_mapping
                        }
                    }
                }
            }
            """
        try:
            results = self.send_query(QUERY)
            self.log.info(f"Query executed successfully")
            data = results.json().get('data', {}).get('caseIncidents', {}).get('edges', [])
            results = [
                {
                    'id': r['node'].get('id'),
                    'name': r['node'].get('name'),
                    'objectParticipant': r['node'].get('objectParticipant'),
                    'status': r['node'].get('status'),
                }
                for r in data
            ]
            self.log.info(f"Number of results: {len(results)}")
            return results
        except ValueError as e:
            self.log.error(f"Query failed: {str(e)}")
            return [{'ERROR': str(e)}]

    def check_ioc_exists(self, ioc):
        QUERY = """
        query StixCyberObservables($types: [String], $filters: FilterGroup) {
                            stixCyberObservables(types: $types, filters: $filters) {
                                edges {
                                    node {
                                        id
                                        entity_type
                                        x_opencti_score
                                        createdBy {
                                            id
                                            name
                                            created
                                            modified
                                        }
                                        observable_value
                                        objectLabel {
                                            id
                                            value
                                        }
                                }
                            }
                            pageInfo {
                                startCursor
                                endCursor
                                hasNextPage
                                hasPreviousPage
                                globalCount
                            }
                        }
                    }
        """
        ioc_type = ioc.ioc_type.type_name
        type = self.ATTRIBUTE_CONFIG[ioc_type].get('type_conversion', 'None')
        key = self.ATTRIBUTE_CONFIG[ioc_type].get('key_conversion', 'value')
        values = [ioc.ioc_value]
        self.log.info(
            f"Checking IOC existence for type: {type}, key: {key}, values: {values}")
        filters = {'mode': 'and', 'filters': [
            {'key': key, 'values': values}], 'filterGroups': []}
        variables = {"types": type,
                     "filters": filters,
                     }
        try:
            result = self.send_query(QUERY, variables)
            if result:
                self.log.info(
                    f"IOC check executed successfully {result.json()}")

                data = result.json().get('data', {}).get(
                    'stixCyberObservables', {}).get('edges', [])
                if data:
                    ioc = data[0]['node']
                    self.log.info(f"IOC exists: {ioc}")
                    return ioc  # IOC exists
                else:
                    return None  # IOC does not exist
            else:
                return {'ERROR': 'Failed to check IOC existence'}
        except ValueError as e:
            self.log.error(f"Check IOC existence failed: {str(e)}")
            return {'ERROR': str(e)}

    def create_ioc(self, ioc):

        QUERY = """
                mutation StixCyberObservableAdd(
                    $type: String!,
                    $stix_id: StixId,
                    $x_opencti_score: Int,
                    $x_opencti_description: String,
                    $createIndicator: Boolean,
                    $createdBy: String,
                    $objectMarking: [String],
                    $objectLabel: [String],
                    $objectOrganization: [String],
                    $externalReferences: [String],
                    $update: Boolean,
                    $AutonomousSystem: AutonomousSystemAddInput,
                    $Directory: DirectoryAddInput,
                    $DomainName: DomainNameAddInput,
                    $EmailAddr: EmailAddrAddInput,
                    $EmailMessage: EmailMessageAddInput,
                    $EmailMimePartType: EmailMimePartTypeAddInput,
                    $Artifact: ArtifactAddInput,
                    $StixFile: StixFileAddInput,
                    $X509Certificate: X509CertificateAddInput,
                    $IPv4Addr: IPv4AddrAddInput,
                    $IPv6Addr: IPv6AddrAddInput,
                    $MacAddr: MacAddrAddInput,
                    $Mutex: MutexAddInput,
                    $NetworkTraffic: NetworkTrafficAddInput,
                    $Process: ProcessAddInput,
                    $Software: SoftwareAddInput,
                    $Url: UrlAddInput,
                    $UserAccount: UserAccountAddInput,
                    $WindowsRegistryKey: WindowsRegistryKeyAddInput,
                    $WindowsRegistryValueType: WindowsRegistryValueTypeAddInput,
                    $CryptographicKey: CryptographicKeyAddInput,
                    $CryptocurrencyWallet: CryptocurrencyWalletAddInput,
                    $Hostname: HostnameAddInput
                    $Text: TextAddInput,
                    $UserAgent: UserAgentAddInput
                    $BankAccount: BankAccountAddInput
                    $PhoneNumber: PhoneNumberAddInput
                    $Credential: CredentialAddInput
                    $TrackingNumber: TrackingNumberAddInput
                    $PaymentCard: PaymentCardAddInput
                    $Persona: PersonaAddInput
                    $MediaContent: MediaContentAddInput
                ) {
                    stixCyberObservableAdd(
                        type: $type,
                        stix_id: $stix_id,
                        x_opencti_score: $x_opencti_score,
                        x_opencti_description: $x_opencti_description,
                        createIndicator: $createIndicator,
                        createdBy: $createdBy,
                        objectMarking: $objectMarking,
                        objectLabel: $objectLabel,
                        update: $update,
                        externalReferences: $externalReferences,
                        objectOrganization: $objectOrganization,
                        AutonomousSystem: $AutonomousSystem,
                        Directory: $Directory,
                        DomainName: $DomainName,
                        EmailAddr: $EmailAddr,
                        EmailMessage: $EmailMessage,
                        EmailMimePartType: $EmailMimePartType,
                        Artifact: $Artifact,
                        StixFile: $StixFile,
                        X509Certificate: $X509Certificate,
                        IPv4Addr: $IPv4Addr,
                        IPv6Addr: $IPv6Addr,
                        MacAddr: $MacAddr,
                        Mutex: $Mutex,
                        NetworkTraffic: $NetworkTraffic,
                        Process: $Process,
                        Software: $Software,
                        Url: $Url,
                        UserAccount: $UserAccount,
                        WindowsRegistryKey: $WindowsRegistryKey,
                        WindowsRegistryValueType: $WindowsRegistryValueType,
                        CryptographicKey: $CryptographicKey,
                        CryptocurrencyWallet: $CryptocurrencyWallet,
                        Hostname: $Hostname,
                        Text: $Text,
                        UserAgent: $UserAgent
                        BankAccount: $BankAccount
                        PhoneNumber: $PhoneNumber
                        Credential: $Credential
                        TrackingNumber: $TrackingNumber
                        PaymentCard: $PaymentCard
                        Persona: $Persona
                        MediaContent: $MediaContent
                    ) {
                        id
                        standard_id
                        entity_type
                        parent_types
                        indicators {
                            edges {
                                node {
                                    id
                                    pattern
                                    pattern_type
                                }
                            }
                        }
                    }
                }
            """

        ioc_type = ioc.ioc_type.type_name
        variables = {
            "type": self.ATTRIBUTE_CONFIG[ioc_type].get('create_type_conversion', 'None'),
        }
        variable_type = self.ATTRIBUTE_CONFIG[ioc_type].get('other_type_conversion', 'None')
        if variable_type == 'StixFile':
            variables['StixFile'] = {
                'name': ioc.ioc_value,
                'hashes': {
                    "algorithm" : self.ATTRIBUTE_CONFIG[ioc_type].get('upload_type'),
                    "hash": ioc.ioc_value
                },
            }
        else:
            variables[variable_type] = {
                'value': ioc.ioc_value,
            }
        try:
            result = self.send_query(QUERY, variables)
            if result:
                self.log.info(f"IOC created successfully {result.json()}")
                return result.json().get('data', {}).get('intrusionSetAdd', {})
            else:
                return {'ERROR': 'Failed to create IOC'}
        except ValueError as e:
            self.log.error(f"Create IOC failed: {str(e)}")
            return {'ERROR': str(e)}