#!/usr/bin/env python3

from iris_interface.IrisModuleInterface import IrisPipelineTypes, IrisModuleInterface, IrisModuleTypes
import iris_interface.IrisInterfaceStatus as InterfaceStatus
import iris_opencti_module.IrisOpenCTIConfig as interface_conf
from iris_opencti_module.opencti_handler.opencti_handler import OpenCTIHandler
from iris_opencti_module.opencti_handler.iris_handler import IrisHandler


# Create our module class
class IrisOpenCTIModule(IrisModuleInterface):

    _module_name = interface_conf.module_name
    _module_description = interface_conf.module_description
    _interface_version = interface_conf.interface_version
    _module_version = interface_conf.module_version
    _pipeline_support = interface_conf.pipeline_support
    _pipeline_info = interface_conf.pipeline_info
    _module_configuration = interface_conf.module_configuration
    _module_type = interface_conf.module_type


    def register_hooks(self, module_id: int):
        """
        Called by IRIS indicating it's time to register hooks.  

        :param module_id: Module ID provided by IRIS.
        """

        self.module_id = module_id
        module_conf = self.module_dict_conf

        hooks_to_manage = {
            'opencti_on_create_hook_enabled': 'on_postload_ioc_create',
            'opencti_on_update_hook_enabled': 'on_postload_ioc_update',
            'opencti_on_delete_hook_enabled': 'on_postload_ioc_delete',
        }

        for config_key, hook_name in hooks_to_manage.items():
            if module_conf.get(config_key):
                status = self.register_to_hook(module_id, iris_hook_name=hook_name)
                if status.is_failure():
                    self.log.error(f"Failed to register {hook_name} hook: {status.get_message()} - {status.get_data()}")
                else:
                    self.log.info(f"Successfully registered {hook_name} hook")
            else:
                self.deregister_from_hook(module_id=self.module_id, iris_hook_name=hook_name)


        # if module_conf.get('opencti_on_create_hook_enabled'):
        #     status = self.register_to_hook(module_id, iris_hook_name='on_postload_ioc_create')
        #     if status.is_failure():
        #         self.log.error(status.get_message())
        #         self.log.error(status.get_data())
        #     else:
        #         self.log.info("Successfully registered on_postload_ioc_create hook")
        # else:
        #     self.deregister_from_hook(module_id=self.module_id, iris_hook_name='on_postload_ioc_create')

        # if module_conf.get('opencti_on_update_hook_enabled'):
        #     status = self.register_to_hook(module_id, iris_hook_name='on_postload_ioc_update')
        #     if status.is_failure():
        #         self.log.error(status.get_message())
        #         self.log.error(status.get_data())
        #     else:
        #         self.log.info("Successfully registered on_postload_ioc_update hook")
        # else:
        #     self.deregister_from_hook(module_id=self.module_id, iris_hook_name='on_postload_ioc_update')

        # if module_conf.get('opencti_on_delete_hook_enabled'):
        #     status = self.register_to_hook(module_id, iris_hook_name='on_postload_ioc_delete')
        #     if status.is_failure():
        #         self.log.error(status.get_message())
        #         self.log.error(status.get_data())
        #     else:
        #         self.log.info("Successfully registered on_postload_ioc_delete hook")
        # else:
        #     self.deregister_from_hook(module_id=self.module_id, iris_hook_name='on_postload_ioc_delete')


    def hooks_handler(self, hook_name: str, hook_ui_name: str, data):
        """
        Called by IRIS each time one of our hook is triggered. 
        """

        self.log.info(f'Received {hook_name}')

        hook_processors = {
            'on_postload_ioc_create': self.create_ioc,
            'on_postload_ioc_update': self.update_ioc,
            'on_postload_ioc_delete': self.delete_ioc,
        }

        function_to_launch = hook_processors.get(hook_name)
        if function_to_launch:
            self.log.info(f'Processing IOC {hook_name.replace("on_postload_ioc_", "").replace("_", " ")} hook')
            status = function_to_launch(data)
        else:
            self.log.critical(f'Received unsupported hook {hook_name}')
            return InterfaceStatus.I2Error(data=data, logs=list(self.message_queue))

        if status.is_failure():
            self.log.error(f"Encountered error processing hook {hook_name}: {status.get_message()}")
            return InterfaceStatus.I2Error(data=data, logs=list(self.message_queue))

        self.log.info(f"Successfully processed hook {hook_name}")
        return InterfaceStatus.I2Success(data=data, logs=list(self.message_queue))

        # self.log.info(f'Received {hook_name}')

        # if hook_name in ['on_postload_ioc_create', 'on_postload_ioc_update', 'on_postload_ioc_delete']:
        #     if hook_name == 'on_postload_ioc_create':
        #         self.log.info('Processing IOC creation hook')
        #         status = self.create_ioc(data)

        #     elif hook_name == 'on_postload_ioc_update':
        #         self.log.info('Processing IOC update hook')
        #         status = self.update_ioc(data)

        #     elif hook_name == 'on_postload_ioc_delete':
        #         self.log.info('Processing IOC delete hook')
        #         status = self.delete_ioc(data)

        # else:
        #     self.log.critical(f'Received unsupported hook {hook_name}')
        #     return InterfaceStatus.I2Error(data=data, logs=list(self.message_queue))

        # if status.is_failure():
        #     self.log.error(f"Encountered error processing hook {hook_name}")
        #     return InterfaceStatus.I2Error(data=data, logs=list(self.message_queue))

        # self.log.info(f"Successfully processed hook {hook_name}")

        # return InterfaceStatus.I2Success(data=data, logs=list(self.message_queue))



    def create_ioc(self, data) -> InterfaceStatus.IIStatus:
        """
        Handle the IOC data the module just received. The module registered
        to on_postload hooks, so it receives instances of IOC object.
        These objects are attached to a dedicated SQlAlchemy session so data can
        be modified safely.

        :param data: Data associated to the hook, here IOC object
        :return: IIStatus
        """

        in_status = InterfaceStatus.IIStatus(code=InterfaceStatus.I2CodeNoError)


        for ioc in data:
            opencti_handler = OpenCTIHandler(mod_config=self._dict_conf, logger=self.log, ioc=ioc)
            opencti_case = opencti_handler.check_case_exists()
            if not opencti_case:
                opencti_case = opencti_handler.create_case()
            else:
                self.log.info(f"OpenCTI case already exists with ID: {opencti_case.get('id')}")
            ioc_result = opencti_handler.check_ioc_exists(ioc)
            if ioc_result:
                self.log.info(f"IOC {ioc.ioc_value} already exists in OpenCTI, skipping creation.")
                pass #TODO: IOC already exists, handle accordingly = link to the IR case
            else:
                ioc_result = opencti_handler.create_ioc(ioc)
            opencti_handler.create_relationship(opencti_case.get('id'), ioc_result.get('id'))



        return in_status(data=data)

    def update_ioc(self, data) -> InterfaceStatus.IIStatus:
        """
        Handle the IOC data the module just received. The module registered
        to on_postload hooks, so it receives instances of IOC object.
        These objects are attached to a dedicated SQlAlchemy session so data can
        be modified safely.

        :param data: Data associated to the hook, here IOC object
        :return: IIStatus
        """

        in_status = InterfaceStatus.IIStatus(code=InterfaceStatus.I2CodeNoError)
        # iris_handler = IrisHandler(logger=self.log)
        # iris_handler.retrieve_case_id_v2(ioc_value=data[0].ioc_value)
        for ioc in data:
            opencti_handler = OpenCTIHandler(mod_config=self._dict_conf, logger=self.log, ioc=ioc)
            opencti_case = opencti_handler.check_case_exists()
            opencti_handler.compare_ioc(opencti_case.get('id'))

        # self.create_ioc(data)

        return in_status(data=data)

    def delete_ioc(self, data) -> InterfaceStatus.IIStatus:
        """
        Handle the IOC data the module just received. The module registered
        to on_postload hooks, so it receives instances of IOC object.
        These objects are attached to a dedicated SQlAlchemy session so data can
        be modified safely.

        :param data: Data associated to the hook, here IOC object
        :return: IIStatus
        """

        in_status = InterfaceStatus.IIStatus(code=InterfaceStatus.I2CodeNoError)
        for ioc in data:
            for attribute_name in dir(ioc):
                if not attribute_name.startswith('__'):
                    try:
                        attribute_value = getattr(ioc, attribute_name)
                        self.log.info(f"{attribute_name}: {attribute_value}")
                    except AttributeError:
                        self.log.info(f"{attribute_name}: <unreadable>")

        # opencti_handler = OpenCTIHandler(mod_config=self._dict_conf, logger=self.log)
        # for ioc in data:
        #     opencti_handler = OpenCTIHandler(mod_config=self._dict_conf, logger=self.log)
        #     result = opencti_handler.check_ioc_exists(ioc)
        #     if result:
        #         self.log.info(f"IOC {ioc.ioc_value} exists in OpenCTI.")
        #         opencti_handler.delete_ioc(ioc)
        #     else:
        #         self.log.info(f"IOC {ioc.ioc_value} don't exists in OpenCTI, skipping deletion.")
        return in_status(data=data)