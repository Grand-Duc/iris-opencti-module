#!/usr/bin/env python3

from iris_interface.IrisModuleInterface import IrisPipelineTypes, IrisModuleInterface, IrisModuleTypes
import iris_interface.IrisInterfaceStatus as InterfaceStatus
import iris_opencti_module.IrisOpenCTIConfig as interface_conf
from iris_opencti_module.opencti_handler.opencti_handler import OpenCTIHandler
from iris_opencti_module.opencti_handler.iris_handler import IrisHandler


class IrisOpenCTIModule(IrisModuleInterface):
    def __init__(self):
        super().__init__()
        # Direct assignment from interface_conf, removing _set_module_configuration method
        self._module_name = interface_conf.module_name
        self._module_description = interface_conf.module_description
        self._interface_version = interface_conf.interface_version
        self._module_version = interface_conf.module_version
        self._pipeline_support = interface_conf.pipeline_support
        self._pipeline_info = interface_conf.pipeline_info
        self._module_configuration = interface_conf.module_configuration
        self._module_type = interface_conf.module_type

    def register_hooks(self, module_id: int):
        self.module_id = module_id
        module_conf = self.module_dict_conf

        hooks_config = {
            'opencti_on_create_hook_enabled': 'on_postload_ioc_create',
            'opencti_on_update_hook_enabled': 'on_postload_ioc_update',
            'opencti_on_delete_hook_enabled': 'on_postload_ioc_delete',
        }

        for config_key, hook_name in hooks_config.items():
            if module_conf.get(config_key):
                status = self.register_to_hook(module_id, iris_hook_name=hook_name)
                if status.is_failure():
                    self.log.error(f"Failed to register {hook_name} hook: {status.get_message()} - {status.get_data()}")
                else:
                    self.log.info(f"Successfully registered {hook_name} hook")
            else:
                # Deregister only if it was previously registered and now disabled
                # This prevents unnecessary deregistration attempts if it was never enabled
                self.deregister_from_hook(module_id=self.module_id, iris_hook_name=hook_name)

    def hooks_handler(self, hook_name: str, hook_ui_name: str, data):
        self.log.info(f'Received {hook_name}')

        hook_processors = {
            'on_postload_ioc_create': self._process_ioc_creation,
            'on_postload_ioc_update': self._process_ioc_update,
            'on_postload_ioc_delete': self._process_ioc_deletion,
        }

        processor = hook_processors.get(hook_name)
        if not processor:
            self.log.critical(f'Received unsupported hook {hook_name}')
            return InterfaceStatus.I2Error(data=data, logs=list(self.message_queue))

        action = hook_name.replace("on_postload_ioc_", "").replace("_", " ")
        self.log.info(f'Processing IOC {action} hook')

        try:
            processor(data)
            self.log.info(f"Successfully processed hook {hook_name}")
            return InterfaceStatus.I2Success(data=data, logs=list(self.message_queue))
        except Exception as e:
            self.log.error(f"Encountered error processing hook {hook_name}: {e}")
            return InterfaceStatus.I2Error(data=data, logs=list(self.message_queue))

    def _process_ioc_creation(self, iocs) -> InterfaceStatus.IIStatus:
        for ioc in iocs:
            try:
                opencti_handler = OpenCTIHandler(mod_config=self._dict_conf, logger=self.log, ioc=ioc)
                opencti_case = opencti_handler.check_case_exists()

                if not opencti_case:
                    opencti_case = opencti_handler.create_case()
                else:
                    self.log.info(f"OpenCTI case already exists with ID: {opencti_case.get('id')} for IOC {ioc.ioc_value}")

                ioc_result = opencti_handler.check_ioc_exists(ioc)
                if ioc_result:
                    self.log.info(f"IOC {ioc.ioc_value} already exists in OpenCTI, skipping creation.")
                    # TODO: IOC already exists, handle accordingly = link to the IR case
                else:
                    ioc_result = opencti_handler.create_ioc(ioc)

                if ioc_result and opencti_case:
                    opencti_handler.create_relationship(opencti_case.get('id'), ioc_result.get('id'))
                else:
                    self.log.warning(f"Skipping relationship creation for IOC {ioc.ioc_value} due to missing OpenCTI case or IOC ID.")

            except Exception as e:
                self.log.error(f"Error processing IOC creation for {ioc.ioc_value}: {e}")
                raise

    def _process_ioc_update(self, iocs) -> InterfaceStatus.IIStatus:
        for ioc in iocs:
            try:
                opencti_handler = OpenCTIHandler(mod_config=self._dict_conf, logger=self.log, ioc=ioc)
                opencti_case = opencti_handler.check_case_exists()
                if opencti_case:
                    self.log.info(f"OpenCTI case found for IOC {ioc.ioc_value}, attempting update.")
                    opencti_handler.compare_ioc(opencti_case.get('id'))
                else:
                    self.log.warning(f"No OpenCTI case found for IOC {ioc.ioc_value} during update, skipping comparison.")
            except Exception as e:
                self.log.error(f"Error processing IOC update for {ioc.ioc_value}: {e}")
                raise

    def _process_ioc_deletion(self, iocs) -> InterfaceStatus.IIStatus:
        for ioc in iocs:
            try:
                opencti_handler = OpenCTIHandler(mod_config=self._dict_conf, logger=self.log, ioc=ioc)
                result = opencti_handler.check_ioc_exists(ioc)
                if result:
                    self.log.info(f"IOC {ioc.ioc_value} exists in OpenCTI, attempting deletion.")
                    opencti_handler.delete_ioc(ioc)
                else:
                    self.log.info(f"IOC {ioc.ioc_value} does not exist in OpenCTI, skipping deletion.")
            except Exception as e:
                self.log.error(f"Error processing IOC deletion for {ioc.ioc_value}: {e}")
                raise