import requests


headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
}

data='10.10.10.10'
url = f'http://127.0.0.1/opencti/iocs/{data}'

response = requests.get(url, json=data, headers=headers)
